import fotoPerfil from './fotoPerfil.jpeg'
import './App.css'

function App() {
  return (
    <div>
      <header>
        <img src={fotoPerfil}></img>
        <h1>Rafael Florindo</h1>
      </header>
    </div>
  );
}

export default App;